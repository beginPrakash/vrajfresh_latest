<?php

class Controller_zipcode extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('zipcode_model');
		$this->load->model('common_model');

		if (!IsUserLogin()) {
			$authorized_error = "You are not authorized to view this page....!";
			$this->session->set_flashdata('authorized_error', $authorized_error);
			redirect('login');
		}

	}
	public function zipcode()
	{
		$ArrData = array();

		$ArrData['Arrzipcode'] = $this->zipcode_model->getZIPCode();

		$ArrState = get_state('', 'US');
		$ArrStateOption = array();
		$ArrStateOption['0'] = "--State--";
		if (count($ArrState) > 0) {
			foreach ($ArrState as $row) {
				$ArrStateOption[$row['state_id']] = $row['state'];
			}
		}
		$ArrData['ArrStateOption'] = $ArrStateOption;

		$ArrData['cms_title'] = 'ZIP Code Configuration';
		$ArrData['view_name'] = 'view_zipcode_configuration.php';
		$this->load->view('admin_panel/admin_panel', $ArrData);
	}
	public function save_zipcode()
	{
		//echo "<pre>";print_r($_POST);
		$zipcode_id = $_POST['zipcode_id'];
		$ArrZipCodeData = $_POST['ArrZipCodeData'];
		$ArrCanDeliverPerishable = $_POST['ArrCanDeliverPerishable'];
		$ArrState = $_POST['ArrState'];
		$ArrDeliveryTypes = $_POST['ArrDeliveryTypes'];
		$ArrDeliveryDays = $_POST['ArrDeliveryDays'];
		if ($zipcode_id > 0) {
			$arrData = array(
				'zipcode' => $ArrZipCodeData[0],
				'area_name' => $ArrZipCodeData[1],
				'town_name' => $ArrZipCodeData[2],
				'minimum_order_value' => $ArrZipCodeData[3],
				'can_deliver_perishable_products' => $ArrCanDeliverPerishable[0],
				'state' => $ArrState[0],
				'delivery_types' => $ArrDeliveryTypes[0],
				'delivery_days' => $ArrDeliveryDays[0],
				'modified_by' => $_SESSION['admin_id'],
				'modified_datetime' => date('Y-m-d'),
			);
			$this->zipcode_model->update($zipcode_id, $arrData);
		} else {
			$arrData = array(
				'zipcode' => $ArrZipCodeData[0],
				'area_name' => $ArrZipCodeData[1],
				'town_name' => $ArrZipCodeData[2],
				'minimum_order_value' => $ArrZipCodeData[3],
				'can_deliver_perishable_products' => $ArrCanDeliverPerishable[0],
				'state' => $ArrState[0],
				'delivery_types' => $ArrDeliveryTypes[0],
				'delivery_days' => $ArrDeliveryDays[0],
				'created_by' => $_SESSION['admin_id'],
				'created_datetime' => date('Y-m-d'),
			);
			$this->zipcode_model->add($arrData);
		}


	}
	public function delete_zipcode()
	{
		$zipcode_id = $_POST['zipcode_id'];
		$this->zipcode_model->delete($zipcode_id);
	}


}