<style>
   .select2-container--open .select2-dropdown--below {
      z-index: 9999999999
   }
</style>

<?php
$order_status = $ArrFieldData['order_status'];
$editAllow = "No";
if ($order_status == 'Pending Payment' || $order_status == 'Processing') {
   $editAllow = "Yes";
}

unset($ArrOrderStatus['Payment Processed']);
$is_payment_received = false;
if(isset($ArrFieldData['amount_received_status']) && $ArrFieldData['amount_received_status']=='succeeded')
{
	$is_payment_received = true;
	$editAllow = "No";
	// Pending Payment and Processing status delete
	unset($ArrOrderStatus['Pending Payment']);
	unset($ArrOrderStatus['Processing']);
}
if($order_status == 'Pending Payment')
{
$is_payment_received = true;
}
?>
<form class="form-horizontal" action="" id="banner_frm" role="form" enctype="multipart/form-data" method="post"
   accept-charset="utf-8">
   <input type="hidden" name="order_id" value="<?php echo $ArrFieldData['order_id']; ?>" />
   <input type="hidden" name="order_total_tax" value="<?php echo $ArrFieldData['order_total_tax']; ?>">
   <input type="hidden" name="state_tax_percentage" id="state_tax_percentage"
      value="<?php echo $ArrFieldData['state_tax']; ?>">
   <input type="hidden" name="product_counter" id="product_counter" value="0" />
   <input type="hidden" name="order_total_amount" id="order_total_amount"
      value="<?php echo $ArrFieldData['order_total_amount']; ?>" />
   <input type="hidden" name="newtotal" id="newtotal" value="" />
   <input type="hidden" name="newpaymentcapture" id="newpaymentcapture"
      value="<?php echo $ArrFieldData['order_total_amount']; ?>">

   <div class="row">
      <div class="col-sm-4">
         <label>Order ID : </label>
         <label style="font-weight:400; line-height: 20px;">
            <?php echo $ArrFieldData['order_id']; ?>
         </label>
      </div>
      <div class="col-sm-4">
         <label>Order Date : </label>
         <label style="font-weight:400; line-height: 20px;">
            <?php echo $ArrFieldData['created_datetime']; ?>
         </label>
      </div>
      <div class="col-sm-4">
         <label>Order Amount : </label>
         <label style="font-weight:400; line-height: 20px;">$
            <span id="labelOrderAmount"><?php echo $ArrFieldData['order_total_amount']; ?></span>
         </label>
      </div>
      <?php if ($ArrFieldData['order_notes'] != '') { ?>
         <div class="col-sm-12">
            <label>Order Notes : </label>
            <label style="font-weight:400; line-height: 20px;">
               <?php echo $ArrFieldData['order_notes']; ?>
            </label>
         </div>
      <?php } ?>
      <div class="col-sm-12">
         <label style="font-weight:400; line-height: 20px;">
            <?php
            if ($ArrFieldData['is_replace_item'] == 1) {
               echo 'Yes, please substitute unavailable items with similar products';
            } else {
               echo 'No, please refund for unavailable items';
            }
            ?>
         </label>
      </div>

      <div class="col-sm-4">
         <label>Total Amount : </label>
         <label style="font-weight:400; line-height: 20px;" id="total_amount_final">$
            <?php echo $ArrFieldData['order_total_amount']; ?>
         </label>
      </div>


   </div>

   <div class="row">
      <div class="col-sm-12">
         <label>
            <h4>Order Products</h4>
         </label>
      </div>
   </div>
   <div class="row">
      <div class="col-sm-12">
         <?php
         if (is_array($ArrOrderProduct) && count($ArrOrderProduct) > 0) {
            ?>
            <table border="1" width="100%" id="product">
               <thead>
                  <tr>
                     <th>Product Name</th>
                     <th>Quantity</th>
                     <th>Price (in $)</th>
                     <th>Product Tax (in $)</th>
                     <th>Total (in $)</th>
                     <th>
                        <?php if ($editAllow == 'Yes') { ?>
                           <a href="javascript:void(0);" onClick="addProductRow()" title="Click here to add new product">
                              <img src="<?php echo admin_media(); ?>dist/img/plus.png">
                           </a>
                        <?php } ?>
                     </th>
                  </tr>
               </thead>
               <tbody>
                  <?php
                  $total_qty = $net_total = 0;
                  //  print_r($ArrOrderProduct);
                  foreach ($ArrOrderProduct as $arr) {
                     $total_qty += $arr['qty'];
                     $net_total += $arr['total_amount'];
                     // echo $net_total;
                     ?>
                     <tr>
                        <td>
                           <input type="hidden" name="ArrOrderProductIds[]" value="<?php echo $arr['order_product_id']; ?>">
                          
						<?php if ($arr['product_variant_size'] == "") {
                                echo $arr['product_name'];
                            } else {
                                echo $arr['product_name'] . ' (' . $arr['product_variant_size'] . ' LB)';
                            } ?>
                        </td>
                        <td>
                           <input type="text" placeholder="QTY" class="form-control qty"
                              id="qty<?php echo $arr['order_product_id']; ?>"
                              name="qty[<?php echo $arr['order_product_id']; ?>]" value="<?php echo $arr['qty']; ?>" required
                              onChange="updateProductTotalAmount(this.value,<?php echo $arr['order_product_id']; ?>);" <?php if ($editAllow != 'Yes') { echo 'readonly'; }?>>
							<input type="hidden" id="oldqty<?php echo $arr['order_product_id']; ?>" name="oldqty[<?php echo $arr['order_product_id']; ?>]" value="<?php echo $arr['qty']; ?>">
                        </td>

                        <td>
                           <input type="text" placeholder="Unit Price" class="form-control"
                              id="unit_price<?php echo $arr['order_product_id']; ?>"
                              name="unit_price[<?php echo $arr['order_product_id']; ?>]"
                              value="<?php echo $arr['unit_price']; ?>" required readonly>
                        </td>

                        <td>
                           <input type="text" placeholder="Product Tax" class="form-control"
                              id="product_tax<?php echo $arr['order_product_id']; ?>"
                              name="product_tax[<?php echo $arr['order_product_id']; ?>]"
                              value="<?php echo $arr['product_tax_amount']; ?>" required readonly>
                        </td>

                        <td>
                           <input type="text" placeholder="Total Amount" class="form-control total_amount"
                              id="total_amount<?php echo $arr['order_product_id']; ?>"
                              name="total_amount[<?php echo $arr['order_product_id']; ?>]"
                              value="<?php echo $arr['total_amount']; ?>" required readonly>
                        </td>
                        <td>
                           <?php if ($editAllow == 'Yes') { ?>
                              <a href="javascript:void(0);" class="remove-button" title="Click here to remove product"
                                 data="<?php echo $arr['order_product_id']; ?>">
                                 <img src="<?php echo admin_media(); ?>dist/img/close-2.png">
                              </a>
                           <?php } ?>
                        </td>
                     </tr>
                  <?php } ?>
               </tbody>
               <tfoot>
                  <tr>
                     <td>Total:</td>
                     <td id="divQTYTotal" style="padding: 6px 13px;">
                        <?php echo $total_qty; ?>
                     </td>
                     <td style="padding: 6px 13px;">--</td>
                     <td style="padding: 6px 13px;">--</td>
                     <td id="divNetTotal" style="padding: 6px 13px;">
                        <?php echo $net_total; ?>
                     </td>
                  </tr>
               </tfoot>
            </table>

         <?php } ?>
      </div>
   </div>
   <div class="row">

      <div class="col-sm-4">
         <!--<select class="form-control select_product_ajax" style="width: 100%;" name="ddIsActive" id="ddIsActive">
                  <option value="1">one</option>
                  <option value="2">two</option>
                  <option value="3">three</option>
                  </select>-->
         <label>Shipping Charge : </label>

         <input type="text" placeholder="Shipping Charge" class="form-control" name="shipping_charge"
            id="shipping_charge" value="<?php echo $ArrFieldData['fedex_shipping_charge']; ?>"
            onChange="updateFooterTotal();" required <?php if ($editAllow == 'No') {
               echo 'readOnly';
            } ?>>

      </div>

      <div class="col-sm-4">
         <label>Tip Amount : </label>
         <input type="text" placeholder="Order Tip" class="form-control" name="order_tip" id="order_tip"
            value="<?php echo $ArrFieldData['order_tip']; ?>" onChange="updateFooterTotal();" required <?php if ($editAllow == 'No') {
                   echo 'readOnly';
                } ?>>
      </div>


      <div class="col-sm-4">
         <label>Order Discount : </label>
         <input type="text" placeholder="Order Discount" class="form-control" name="discount_amount"
            id="discount_amount" value="<?php echo $ArrFieldData['discount_amount']; ?>"
            onChange="updateFooterTotal();" required <?php if ($editAllow == 'No') {
               echo 'readOnly';
            } ?>>
      </div>

      <div class="col-sm-4">
         <label>Preparation Cost: </label>
         <input type="text" placeholder="Preparation Cost" class="form-control" id="preparation_cost"
            name="preparation_cost" value="<?php echo $ArrFieldData['preparation_cost']; ?>"
            onChange="updateFooterTotal();" required readonly>
      </div>

      <div class="col-sm-4">
         <label>Packaging Cost: </label>
         <input type="text" placeholder="Packaging Cost" class="form-control" id="packaging_cost" name="packaging_cost"
            id="discount_amount" value="<?php echo $ArrFieldData['packaging_cost']; ?>" onChange="updateFooterTotal();"
            required readonly>
      </div>

      <div class="col-sm-4">
         <label>State Tax:(in %)</label>
         <input type="text" placeholder="State Tax" class="form-control" name="order_total_tax" id="order_total_tax"
            value="<?php echo $ArrFieldData['state_tax']; ?>" onChange="updateFooterTotal();" required readonly>
      </div>

      <div class="col-sm-4">
         <label>Order Status : </label>
         <?php
		 if($order_status=='Payment Processed')
		 {
			 echo "Payment Processed";
		 }
		 else
		 {
		 echo form_dropdown('order_status', $ArrOrderStatus, $order_status, 'id="order_status" class="form-control"');
		 }
         ?>
      </div>
   </div>

   <div class="row">
      <div class="col-sm-6">
         <label>Billing Address : </label>
         <div>
            <?php echo 'Name:' . $ArrFieldData['shipping_first_name'] . ' ' . $ArrFieldData['shipping_last_name'] . '<br>' . $ArrFieldData['billing_street_name'] . ' ' . $ArrFieldData['billing_apartment_name'] . ' , ' . $ArrFieldData['billing_city'] . ' , ' . $ArrFieldData['billing_state_name'] . ' , ' . $ArrFieldData['billing_zipcode'] . '<br>Contact No. ' . $ArrFieldData['billing_phone']; ?>
         </div>
      </div>

      <div class="col-sm-6">
         <label>Shipping Address : </label>
         <div>
            <?php echo 'Name:' . $ArrFieldData['shipping_first_name'] . ' ' . $ArrFieldData['shipping_last_name'] . '<br>' . $ArrFieldData['shipping_street_name'] . ' ' . $ArrFieldData['shipping_apartment_name'] . ' , ' . $ArrFieldData['shipping_city'] . ' , ' . $ArrFieldData['shipping_state_name'] . ' , ' . $ArrFieldData['shipping_zipcode'] . '<br> Email: ' . $ArrFieldData['shipping_email'] . '<br>Contact No. ' . $ArrFieldData['shipping_phone']; ?>
         </div>
      </div>
   </div>


   <div class="row">
      <div class="col-sm-12">
         <br>
         <button type="button" class="btn btn-default" name="submit" id="submit" value="Submit">Update Order</button>
      </div>
   </div>

</form>
<?php if (!$is_payment_received) { ?>


    <script type="text/javascript">
      //set your publishable key
      Stripe.setPublishableKey('<?php echo STRIPE_PUBLISHABLE_KEY ?>');

      //callback to handle the response from stripe
      function stripeResponseHandler(status, response) {
        if (response.error) {
          //enable the submit button
          $('#payBtn').removeAttr("disabled");
		  
          //display the errors on the form
          $('#payment-errors').addClass('alert alert-danger');
          $("#payment-errors").html(response.error.message);
        } else {
          var form$ = $("#paymentFrm");
          //get token id
          var token = response['id'];
		  
          //insert the token into the form
          form$.append("<input type='hidden' name='stripeTempToken' value='" + token + "' />");
          //submit form to the server
          form$.get(0).submit();
        }
      }
	  
	  
		
    </script>
   <form class="form-horizontal" action='' id="paymentFrm" role="form" enctype="multipart/form-data" method="post"
      accept-charset="utf-8">
      <br>
      <div class="row">
         <div class="col-sm-4">
            <input type="hidden" name="payment_intent_id" value="<?php echo $ArrFieldData['payment_intent_id']; ?>" />
            <input type="hidden" name="order_id" value="<?php echo $ArrFieldData['order_id']; ?>" />
            <input type="hidden" name="stripeToken" value="<?php echo $ArrFieldData['payment_intent_id'] . "-" . $ArrFieldData['order_id']; ?>" />
            <input type="hidden" name="amount_to_capture" id="amount_to_capture"  value="<?php echo $ArrFieldData['order_total_amount']; ?>" />
            <input type="hidden" name="blocked_amount" id="blocked_amount"  value="<?php echo $ArrFieldData['blocked_amount']; ?>" />
			   
			<input type="hidden" name="name" id="name" value="<?php echo $ArrFieldData['shipping_first_name'] . ' ' . $ArrFieldData['shipping_last_name']; ?>">
			<input type="hidden" name="email" id="email" value="<?php echo $ArrFieldData['shipping_email']; ?>">
			<input type="hidden" name="zip_code" id="zip_code" value="<?php echo $ArrFieldData['billing_zipcode']; ?>">
			<input type="hidden" name="card_num" id="card_num" value="<?php echo $ArrUser['card_num']; ?>">
			<input type="hidden" name="exp_month" id="card-expiry-month" value="<?php echo $ArrUser['card_exp_month']; ?>">
			<input type="hidden" name="exp_year" id="card-expiry-year" value="<?php echo $ArrUser['card_exp_year']; ?>">
			<input type="hidden" name="cvc" id="card-cvc" value="<?php echo $ArrUser['card_cvc']; ?>">
         </div>
         <div class="col-sm-4">
            <button type="button" id="payBtn" class="btn btn-success">Capture Payment</button>
         </div>
      </div>
   </form>
<?php } ?>
<script>
   $(document).ready(function () {
      $("#product").on('click', '.remove-button', function (e) {
         if (confirm("Do you want to remove order product?") == true) {
            RemoveProductFromOrder($(this).attr("data"));
            var whichtr = $(this).closest("tr");
            whichtr.remove();
            var product_counter = parseInt($("#product_counter").val());
            product_counter = product_counter - 1;
            $("#product_counter").val(product_counter);
            updateFooterTotal();
         }
      });
   });
   $("#submit").click(function () {
      $.ajax({
         url: '<?php echo site_url(); ?>update-order-process/',
         type: 'POST',
         data: $('form#banner_frm').serialize(),
         success: function (data) {
            toastr.success('Order has been updated successfully!');
            $("#searchSubmit").click();
            $(".close").click();
         }
      });
   });
   $("#payBtn").click(function () {
	   //alert('payBtn');
	   //create single-use token to charge the user
          Stripe.createToken({
            number: $('#card_num').val(),
            cvc: $('#card-cvc').val(),
            exp_month: $('#card-expiry-month').val(),
            exp_year: $('#card-expiry-year').val()
          }, stripeResponseHandler);
		 //alert('tettt');
      $.ajax({
         url: '<?php echo site_url(); ?>order-payment-capture/',
         type: 'POST',
         data: $('form#paymentFrm').serialize(),
         success: function (data) {
			 console.log(data);
			//alert('data');
            toastr.success('Order payment captured successfully!!!!');
            $(".close").click();
         }
      });
   });
   function addProductRow() {
      var product_counter = parseInt($("#product_counter").val());
      product_counter = product_counter + 1;
      $("#product_counter").val(product_counter);
     // var data = '<tr><td><select name="ArrNewProducts[]" id="" onChange="SetPrice(this.value,' + product_counter + ');" class="form-control select_product_ajax" required></select></td><td><input type="text" placeholder="QTY" class="form-control" id="qty' + product_counter + '" name="ArrNewQty[]" value="" required onChange="updateProductTotalAmount(this.value,' + product_counter + ');"></td><td><input type="text" placeholder="Unit Price" class="form-control" id="unit_price' + product_counter + '" name="ArrNewUnit_price[]" value="" required readonly></td><td><input type="text" placeholder="Product Tax" class="form-control" id="product_tax' + product_counter + '" name="ArrNewproduct_tax[]" value="" required readonly></td><td><input type="text" placeholder="Total Amount" class="form-control total_amount" id="total_amount' + product_counter + '" name="ArrNewTotal_amount[]" value="" required readonly></td><td><a href="javascript:void(0);" class="remove-button" title="Click here to remove product"><img src="<?php echo admin_media(); ?>dist/img/close-2.png"></a></td></tr>';
      //$('#product').append(data);
      $.ajax({
         type: "POST",
         url: "<?php echo site_url(); ?>getCartProductRow/" + product_counter,
         success: function (data) {
            $('#product').append(data);
            $('.select_product_ajax').select2();
            //ajax_page_drop_down();
         }
      });
   }

   function RemoveProductFromOrder(order_product_id) {
      $.ajax({
         type: "POST",
         url: "<?php echo site_url(); ?>remove-order-process/" + order_product_id,
         success: function (data) {
            updateFooterTotal();
         }
      });
   }

   function SetPrice(val, product_counter) {
      const ArrProductDetails = val.split("|");
      //Format: product_id-variant_id-variant_price-product_name
      $("#qty" + product_counter).val(1);
      $("#unit_price" + product_counter).val(ArrProductDetails[2]);
      var product_tax = ArrProductDetails[4];
      var state_tax_percentage = $("#state_tax_percentage").val();

      var product_tax_amount = 0;
      //if flag - product_tax = 0 then calculate product tax
      if (product_tax == 0) {
         product_tax_amount = parseFloat((1 * ArrProductDetails[2] * state_tax_percentage) / 100);
         $("#product_tax" + product_counter).val(state_tax_percentage);
      } else {
         $("#product_tax" + product_counter).val(0);
      }
	  console.log(ArrProductDetails[2]);
      $("#total_amount" + product_counter).val(parseFloat((1 * ArrProductDetails[2]) + product_tax_amount).toFixed(2));
      updateFooterTotal();
   }

   function updateProductTotalAmount(val, product_counter) {
      var product_tax_amount = 0;
      if ($("#product_tax" + product_counter).val() > 0) {
         product_tax_amount = parseFloat((val * $("#unit_price" + product_counter).val() * $("#product_tax" + product_counter).val()) / 100);
      }
      var temp_total = parseFloat(val * $("#unit_price" + product_counter).val() + product_tax_amount);
      $("#total_amount" + product_counter).val(temp_total.toFixed(2));
      updateFooterTotal();
   }

   function updateFooterTotal() {
      var QTYTotal = 0;
      var NetTotal = 0;
      $('.qty').each(function () {
         QTYTotal = QTYTotal + parseInt($(this).val());
      });
      $('.total_amount').each(function () {
         NetTotal = NetTotal + parseFloat($(this).val());
         // alert($(this).val());
      });
      $("#divQTYTotal").html(QTYTotal);
      //$("#divNetTotal").html(NetTotal);
      //NetTotal = Math.round(NetTotal).toFixed(2);
      $("#divNetTotal").html(NetTotal.toFixed(2));

      var totalordrvalue = $("#order_total_amount").val();
      //update capture amount
      var total = (parseFloat(NetTotal.toFixed(2)) + parseFloat($("#shipping_charge").val()) + parseFloat($("#order_tip").val()) + parseFloat($("#preparation_cost").val()) + parseFloat($("#packaging_cost").val())).toFixed(2);
      console.log(total);

      var capture_total_extra = (parseFloat(total) - parseFloat(totalordrvalue)).toFixed(2);

      var newtotal = $("#newtotal").val(total);
      $("#total_amount_final").html('$' + total);
      $("#labelOrderAmount").html(total);
      console.log(capture_total_extra);

      var capture_total = total - parseFloat($("#discount_amount").val());

      $("#newpaymentcapture").val(capture_total_extra);

      $("#amount_to_capture").val(capture_total_extra);

   }
</script>

<?php if(is_array($ArrOrderTransactions) && count($ArrOrderTransactions)>0) { ?>

         <label>Transactions : </label>
            <table border="1" width="100%" id="transaction">
		<thead>
			<th>Transaction ID</th>
			<th>Type</th>
			<th>Status</th>
			<th>Amount ($)</th>
			<th>Date & Time</th>
		</thead>
		<?php foreach($ArrOrderTransactions as $data) { ?>
		<tr>
			<td><?php echo $data['transaction_id']; ?></td>
			<td><?php echo $data['payment_process_type']; ?></td>
			<td><?php echo $data['payment_intent_status']; ?></td>
			<td><?php echo $data['transaction_amount']; ?></td>
			<td><?php echo $data['transaction_datetime']; ?></td>
		</tr>
		<?php } ?>
	</table>
<?php } ?>